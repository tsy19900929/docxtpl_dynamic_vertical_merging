# To install using pip
* download docxtpl_dynamic_vertical_merging.zip && pip3 install docxtpl_dynamic_vertical_merging.zip
* pip3 install git+https://github.com/tsy19900929/docxtpl_dynamic_vertical_merging.git

# Usage
* test1
* test2
